<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Folder in footer body' => 'Папка внизу страницы',
    'Folder in footer bottom' => 'Папка в подвале страницы',
    'Latest articles' => 'Последние статьи',
    'Sorry, an error occurred: %err' => 'К сожалению произошла ошибка: %err',
];

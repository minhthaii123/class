<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Facebook username' => 'Facebook Benutzername',
    'Follow us' => 'Folgen Sie uns',
    'Google + username' => 'Google+ Benutzername',
    'Instagram username' => 'Instagram Benutzername',
    'Pinterest username' => 'Pinterest Benutzername',
    'RSS URL' => 'RSS-URL',
    'Twitter username' => 'Twitter Benutzername',
    'Youtube URL' => 'YouTube-URL',
];

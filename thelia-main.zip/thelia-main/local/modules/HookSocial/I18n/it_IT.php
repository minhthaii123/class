<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Facebook username' => 'Nome utente Facebook',
    'Follow us' => 'Seguici',
    'Google + username' => 'Nome utente Google +',
    'Instagram username' => 'Nome utente Instagram',
    'Pinterest username' => 'Nome utente Pinterest',
    'RSS URL' => 'RSS URL',
    'Twitter username' => 'Nome utente Twitter',
    'Youtube URL' => 'Youtube URL',
];

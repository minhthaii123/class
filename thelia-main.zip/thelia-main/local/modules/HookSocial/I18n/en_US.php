<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Facebook username' => 'Facebook username',
    'Follow us' => 'Follow us',
    'Google + username' => 'Google + username',
    'Instagram username' => 'Instagram username',
    'Pinterest username' => 'Pinterest username',
    'RSS URL' => 'RSS URL',
    'Twitter username' => 'Twitter username',
    'Youtube URL' => 'Youtube URL',
];

<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Facebook username' => 'Имя пользователя Facebook',
    'Follow us' => 'Мы в соц сетях',
    'Google + username' => 'Имя пользователя Google +',
    'Instagram username' => 'Имя пользователя Instagram',
    'Pinterest username' => 'Имя пользователя Pinterest',
    'RSS URL' => 'RSS URL',
    'Twitter username' => 'Имя пользователя Twitter',
    'Youtube URL' => 'Youtube URL',
];

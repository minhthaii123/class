<?php

/*
 * This file is part of the Thelia package.
 * http://www.thelia.net
 *
 * (c) OpenStudio <info@thelia.net>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

return [
    'Sales statistics' => 'Statistiques de vente',
    'Stats on %month/%year' => 'Statistiques pour %month/%year',
    'Thelia Github activity' => 'Thelia sur Github',
    'Thelia news' => 'Actualité Thelia',
];

JQuery UI datepicker localization files were found here : https://github.com/jquery/jquery-ui/tree/master/ui/i18n

Warning : You must change file name an localization array key declaration in file to match thelia lang locale.

Exemple : change fr with fr_FR
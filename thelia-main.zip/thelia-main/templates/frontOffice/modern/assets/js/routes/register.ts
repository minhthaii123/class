import StateSelect from '@components/smarty/StateSelect/StateSelect';
import HandleRecaptcha from '@standalone/HandleRecaptcha';


StateSelect();
HandleRecaptcha(document.getElementById('RegisterForm'));

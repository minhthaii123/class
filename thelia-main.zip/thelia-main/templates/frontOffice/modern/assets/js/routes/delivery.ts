import Checkout from '@components/smarty/Checkout/Checkout';

Checkout();

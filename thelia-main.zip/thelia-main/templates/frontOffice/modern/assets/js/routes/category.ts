import CategoryMenu from '@components/smarty/CategoryMenu/CategoryMenu';

CategoryMenu();

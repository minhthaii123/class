import StateSelect from '@components/smarty/StateSelect/StateSelect';

StateSelect();

import ProductGallery from '@components/smarty/ProductGallery/ProductGallery';
import PseSelector from '@components/React/PseSelector';
import Selection from '@components/smarty/Selection/Selection';
//import zoom from '@js/utils/zoom';

ProductGallery();
PseSelector();
Selection();
// zoom();

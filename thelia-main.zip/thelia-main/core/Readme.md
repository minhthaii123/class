## This is an extracted repository of Thelia core ([Original emplacement here](https://github.com/thelia/thelia/tree/main/core)).
## ⚠ All the pull requests on this repo will be ignored. ⚠
### If you want to create a project, please take a look at [thelia/thelia-project](https://github.com/thelia/thelia-project)
### If you want to contribute to Thelia, please take a look at [thelia/thelia](https://github.com/thelia/thelia)
